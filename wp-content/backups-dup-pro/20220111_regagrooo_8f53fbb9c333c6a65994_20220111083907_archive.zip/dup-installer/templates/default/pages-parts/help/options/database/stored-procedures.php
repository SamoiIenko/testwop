<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Stored Procedures</td>
    <td>
        Enable creation of stored procedures. Checked by default.
    </td>
</tr>
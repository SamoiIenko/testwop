<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Database Search</td>
    <td>
        Database Full search forces a scan of every single cell in the database. 
        If it is not checked then only text based columns are searched which makes the update process much faster.
        Use this option if you have issues with data not updating correctly.
    </td>
</tr>
<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Table Prefix</td>
    <td>
        This option allows changing table prefix to other than the package creation site's table prefix. 
        The table prefix is the value placed in the front of your database tables. 
        It is possible to have multiple installations in one database if you give each WordPress site a unique prefix.
    </td>
</tr>
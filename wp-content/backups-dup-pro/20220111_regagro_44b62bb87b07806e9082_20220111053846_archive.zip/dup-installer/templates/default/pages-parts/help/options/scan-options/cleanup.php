<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Cleanup <sup>pro</sup></td>
    <td>
        The checkbox labeled Remove schedules &amp; storage endpoints will empty the Duplicator schedule and storage settings.  
        This is recommended to keep enabled so that you do not have unwanted schedules and storage options enabled.
    </td>
</tr>
<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Directory Permissions</td>
    <td>
        Switch on and set permission in either octal or symbolic values to assign permissions to directories, This option is not available on Windows machines.
    </td>
</tr>
<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Password</td>
    <td>The password of the cPanel user</td>
</tr>
<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<style>
    .recovery-main-info {
        text-align: center;
        margin: 0 100px;
    }    
</style>